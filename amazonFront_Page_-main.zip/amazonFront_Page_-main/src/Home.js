import React from 'react'
import './Home.css';
import Product from './Product.js'
function Home() {
  return (
    <div className='home'>
    <div className='home_container'>
    <img className ="home_img" src='https://images-eu.ssl-images-amazon.com/images/G/31/img20/2022/under1999/1999_Tallhero_3000x1200_n._CB636771823_.jpg'
    alt=''/>
   {/*   <div className='home_row'>
          <Product 
          title='The Jungle Book' 
          price={150} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />

<Product 
          title='Mi Step Out 12 L Mini Backpack'
          price={299} 
          image='https://m.media-amazon.com/images/I/71edjA10hZL._SY450_.jpg' 
          rating={4} 
          />

<Product 
          title='The Jungle Book' 
          price={150} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />


          </div>


          <div className='home_row'>
          <Product 
          title='D Shoes Sports' 
          price={'Clearance Sale'} 
          image='https://m.media-amazon.com/images/I/81i057rz8gS._UL1500_.jpg' 
          rating={1} 
          />

<Product 
          title='The Jungle Book' 
          price={200} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />

<Product 
          title='The Jungle Book' 
          price={200} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />


          </div>
      
          <div className='home_row'>
          <Product 
          title='AmazonBasics 127 cm (50 inches) 4K Ultra HD Smart LED Fire TV AB50U20PS (Black)' 
          price={'Clearance Sale'} 
          image='https://m.media-amazon.com/images/I/71sFjIGl9UL._SX450_.jpg' 
          rating={4} 
          />
            <Product 
          title='The Jungle Book' 
          price={350} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />
            <Product 
          title='The Jungle Book' 
          price={450} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />

<Product 
          title='The Jungle Book' 
          price={100} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />

<Product 
          title='The Jungle Book' 
          price={500} 
          image='https://images-eu.ssl-images-amazon.com/images/I/51145PXMgYL._AC_SX184_.jpg' 
          rating={2} 
          />
          </div>
  */}
    </div>
    </div>
  )
}

export default Home